/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joagnpmoviesf21;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
/**
 *
 * @author Justin Agudah (joagnp)
 */
public class JoagnpMoviesF21 {
    DateFormat dtf = new SimpleDateFormat("MM-DD-YYYY h:mm aa");
    DateFormat dateFormat = new SimpleDateFormat("MMM D, YYYY");
    
    public enum Genre {ACTION, ANIMATION, COMEDY, DRAMA, FANTASY, HORROR,
                        ROMANCE, SCI_FI, SUSPENSE, WESTERN, KIDS, UNKNOWN};
    
    public static int numOfMovies = 0;
    
    public static class Movie extends JoagnpMoviesF21 {
        private String name;
        private String director;
        private String summary;
        private String rating;
        private double revenue = 0.0;
        private Genre genre;
        private String releaseDate;
        private String runtime;
        private int version;
        
        public Movie(String name, String director, String summary, String rating, 
                double revenue, Genre genre, String releaseDate, String runtime){
            this(name, director, summary, genre, releaseDate, runtime);
            this.revenue = revenue;
            this.rating = rating;
            version = 1;
        }
        public Movie(String name, String director, String summary, Genre genre, 
                String releaseDate, String runtime){
            this(name, director, runtime);
            this.summary = summary;
            this.genre = genre;
            this.releaseDate = releaseDate;
            version = 1;
        }
        public Movie(String name, String director, String runtime){
            this();
            this.name = name;
            this.director = director;
            this.runtime = runtime;
        }
        public Movie(){
            name = "";
            director = "";
            releaseDate = "October 14, 1888";
            version = 0;
            numOfMovies++;
        }
        
        public void incrementVersion(){version++;}
        
        public void setName(String name){
            this.name = name;
            incrementVersion();
        }
        public void setDirector(String director){
            this.director = director;
            incrementVersion();
        }
        public void setRating(String rating){
            this.rating = rating;
            incrementVersion();
        }
        public void setRevenue(double revenue){this.revenue = revenue;}
        public void setReleaseDate(String releaseDate){
            this.releaseDate = releaseDate;
            incrementVersion();
        }
        public void setGenre(Genre genre){
            this.genre = genre;
            incrementVersion();
        }
        public void setSummary(String summary){
            this.summary = summary;
            incrementVersion();
        }
        public void setRuntime(String runtime){this.runtime = runtime;}
        
        public String getName(){return name;}
        public String getDirector(){return director;}
        public String getRating(){return rating;}
        public double getRevenue(){return revenue;}
        public String getReleaseDate(){return releaseDate;}
        public Genre getGenre(){return genre;}
        public String getSummary(){return summary;}
        public int getVersion(){return version;}
        public String getRuntime(){return runtime;}
        public void playMovie(){
            System.out.print("The runtime of " + this.name + " is " + this.runtime + "\n\n");
        }
        public void print(){
            System.out.print("Name: " + this.name + "\n");
            System.out.print("Director: " + this.director + "\n");
            System.out.print("Summary: " + this.summary + "\n");
            System.out.print("Genre: " + this.genre + "\n");
            System.out.print("Rating: " + this.rating + "\n");
            System.out.print("Revenue: $" + this.revenue + "\n");
            System.out.print("Release Date: " + this.releaseDate + "\n");
            System.out.print("Runtime: " + this.runtime + "\n");
            System.out.print("Version: " + this.version + "\n");
            this.playMovie();
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Movie movie1 = new Movie("BLACK WIDOW", "Cate Shortland", "2h13");
        movie1.setGenre(Genre.ACTION);
        movie1.setSummary("Natasha Romanoff, aka Black Widow,\n" +
            "confronts the darker parts of her ledger when a dangerous conspiracy with ties to her past\n" +
            "arises. Pursued by a force that will stop at nothing to bring her down, Natasha must deal with\n" +
            "her history as a spy, and the broken relationships left in her wake long before she became an\n" +
            "Avenger.");
        movie1.setRating("PG-13");
        movie1.setRevenue(181500000);
        movie1.setReleaseDate("Jul 9, 2021");
        
        Movie movie2 = new Movie("TOYS OF TERROR", "Nicholas Verso", "Evil toys magically\n" +
            "come to life to terrorize a couple and their children inside a secluded mansion.", "R", 0, 
            Genre.HORROR, "Oct 25, 2020", "1h29m");
        
        Movie movie3 = new Movie("THE LION KING", "Jon Favreau", "After the murder of his\n" +
            "father, a young lion prince flees his kingdom only to learn the true meaning of responsibility\n" +
            "and bravery.", Genre.KIDS, "Aug 27, 2019", "1h58m");
        movie3.setRating("PG");
        movie3.setRevenue(543600000);
        
        Movie movie4 = new Movie();
        movie4.setName("KILLER JOE");
        movie4.setDirector("William Friedkin");
        movie4.setSummary("A cop\n" +
            "(Matthew McConaughey) who moonlights as a hit man agrees to kill the hated mother\n" +
            "of a desperate drug dealer (Emile Hirsch) in exchange for a tumble with the young\n" +
            "man's virginal sister (Juno Temple).");
        movie4.setGenre(Genre.DRAMA);
        movie4.setRating("TVMA");
        movie4.setRevenue(2000000);
        movie4.setReleaseDate("Dec 21, 2012");
        movie4.setRuntime("1h41m");
        
        //Referenced from https://en.wikipedia.org/wiki/Demon_Slayer:_Kimetsu_no_Yaiba_the_Movie:_Mugen_Train
        Movie myFavMovie = new Movie("DEMON SLAYER: KIMETSU NO YAIBA THE MOVIE: MUGEN TRAIN", "Haruo Sotozaki", 
            "A boy raised by boars, who wears a boar's head, boards the Infinity Train on a new mission with the \n"
            + "Flame Pillar along with another boy who reveals his true power when he sleeps. \n"
            + "Their mission is to defeat a demon who has been tormenting people and killing the demon slayers \n"
            + "who oppose it.", "R", 503000000, Genre.ANIMATION, "Apr 23, 2021", "1h57m");
        //END OF REFERENCE
        
        System.out.print("MOVIE 1:\n");
        System.out.print("Name: " + movie1.getName() + "\n");
        System.out.print("Director: " + movie1.getDirector() + "\n");
        System.out.print("Summary: " + movie1.getSummary() + "\n");
        System.out.print("Genre: " + movie1.getGenre() + "\n");
        System.out.print("Rating: " + movie1.getRating() + "\n");
        System.out.print("Revenue: $" + movie1.getRevenue() + "\n");
        System.out.print("Release Date: " + movie1.getReleaseDate() + "\n");
        System.out.print("Runtime: " + movie1.getRuntime() + "\n");
        System.out.print("Version: " + movie1.getVersion() + "\n");
        movie1.playMovie();
        
        System.out.print("MOVIE 2:\n");
        System.out.print("Name: " + movie2.getName() + "\n");
        System.out.print("Director: " + movie2.getDirector() + "\n");
        System.out.print("Summary: " + movie2.getSummary() + "\n");
        System.out.print("Genre: " + movie2.getGenre() + "\n");
        System.out.print("Rating: " + movie2.getRating() + "\n");
        System.out.print("Revenue: $" + movie2.getRevenue() + "\n");
        System.out.print("Release Date: " + movie2.getReleaseDate() + "\n");
        System.out.print("Runtime: " + movie2.getRuntime() + "\n");
        System.out.print("Version: " + movie2.getVersion() + "\n");
        movie2.playMovie();
        
        System.out.print("MOVIE 3:\n");
        movie3.print();
        
        System.out.print("MOVIE 4:\n");
        movie4.print();
        
        System.out.print("MOVIE 5:\n");
        myFavMovie.print();
        
        System.out.print("Number of movies: " + Movie.numOfMovies + "\n");
    }
    
}
