/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joagnpgpacalculatorf21;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Justin Agudah (joagnp)
 */
public class JoagnpGPACalculatorF21 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button calculateGPA = new Button();
        calculateGPA.setText("Calculate GPA Score");
        calculateGPA.setMaxWidth(Double.MAX_VALUE);
        
        Button showStats = new Button();
        showStats.setText("Show Statistics");
        showStats.setMaxWidth(Double.MAX_VALUE);
        
        Button alert = new Button();
        alert.setText("Alert");
        alert.setMaxWidth(Double.MAX_VALUE);
        
        Button clearAll = new Button();
        clearAll.setText("Clear All");
        clearAll.setMaxWidth(Double.MAX_VALUE);
        
        Label course1 = new Label();
        course1.setText("Course 1 :");
        
        Label course2 = new Label();
        course2.setText("Course 2 :");
        
        Label course3 = new Label();
        course3.setText("Course 3 :");
        
        Label course4 = new Label();
        course4.setText("Course 4 :");
        
        Label info = new Label();
        info.setText("Information:");
        
        TextField score1 = new TextField();
        score1.setPrefWidth(350);
        
        TextField score2 = new TextField();
        score2.setPrefWidth(350);
        
        TextField score3 = new TextField();
        score3.setPrefWidth(350);
        
        TextField score4 = new TextField();
        score4.setPrefWidth(350);
        
        TextArea infoArea = new TextArea();
        infoArea.setPrefRowCount(3);
        infoArea.setWrapText(true);
        infoArea.setEditable(false);
        
        calculateGPA.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                int SCORE1 = Integer.parseInt(score1.getText());
                int SCORE2 = Integer.parseInt(score2.getText());
                int SCORE3 = Integer.parseInt(score3.getText());
                int SCORE4 = Integer.parseInt(score4.getText());
                double avgScore = ((SCORE1 + SCORE2 + SCORE3 + SCORE4) / 4.0);
                
                infoArea.setText("Your average scre is: ((" + SCORE1 + '+' + SCORE2
                    + '+' + SCORE3 + '+' + SCORE4 + ")/4) =" + avgScore + "\n");
                if(avgScore >= 87 && avgScore < 100)
                    infoArea.setText("Your GPA is: A\n");
                else if(avgScore >= 77)
                    infoArea.setText("Your GPA is: B\n");
                else if(avgScore >= 67)
                    infoArea.setText("Your GPA is: C\n");
                else if(avgScore >= 60)
                    infoArea.setText("Your GPA is: D\n");
                else if(avgScore >= 0)
                    infoArea.setText("Your GPA is: F\n");
                }});
        
        showStats.setOnAction(new EventHandler<ActionEvent>(){
            
            @Override
            public void handle(ActionEvent event) {
                
                int[] scores = new int[4];
                scores[0] = Integer.parseInt(score1.getText());
                scores[1] = Integer.parseInt(score2.getText());
                scores[2] = Integer.parseInt(score3.getText());
                scores[3] = Integer.parseInt(score4.getText());
                int max = scores[0];
                int min = scores[0];
                
                for(int i=0; i<4; i++){
                    if(scores[i] > max)
                        max = scores[i];
                    else if(scores[i] < min)
                        min = scores[i];
                }
                
                infoArea.setText("Your highest score is: " + max + "\n");
                infoArea.setText("Your lowest score is: " + min + "\n");
            }
        });
        
        alert.setOnAction(new EventHandler<ActionEvent>(){
            
            @Override
            public void handle(ActionEvent event) {
                infoArea.setText("There is nothing to display");
            }
        });
        
        clearAll.setOnAction(new EventHandler<ActionEvent>(){
            
            @Override
            public void handle(ActionEvent event) {
                
                score1.clear();
                score2.clear();
                score3.clear();
                score4.clear();
                infoArea.clear();
            }
        });
        
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(15));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.BASELINE_CENTER);
        
        grid.add(course1, 0, 0, 1, 1);
        grid.add(score1, 1, 0, 1, 1);
        grid.add(course2, 0, 1, 1, 1);
        grid.add(score2, 1, 1, 1, 1);
        grid.add(course3, 0, 2, 1, 1);
        grid.add(score3, 1, 2, 1, 1);
        grid.add(course4, 0, 3, 1, 1);
        grid.add(score4, 1, 3, 1, 1);
        grid.add(info, 0, 4, 2, 1);
        grid.add(infoArea, 0, 5, 2, 1);
        
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(calculateGPA, showStats, alert, clearAll);
        grid.add(vbox, 0, 6, 2, 1);
        
        Scene scene = new Scene(grid, 500, 425);
        
        primaryStage.setTitle("GPA Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
