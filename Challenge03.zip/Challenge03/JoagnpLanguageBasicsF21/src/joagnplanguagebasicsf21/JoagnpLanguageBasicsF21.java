/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joagnplanguagebasicsf21;
import java.util.Random;
import java.time.format.DateTimeFormatter;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;
/**
 *
 * @author Justin Agudah
 */
public class JoagnpLanguageBasicsF21 {
    
        static void invokeMe(String hello, String pawprint){
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/dd/YYYY");
            DateFormat timeFormat = new SimpleDateFormat("h:mm aa");
        
            System.out.print(hello + ", my pawprint is " + pawprint + " and ");
            System.out.print("today's date is " + dateFormat.format(java.time.LocalDate.now()) + " ");
            System.out.print(timeFormat.format(new Date()) + "\n");
        }
    /**
     * @param args the command line arguments
     */
            
    public static void main(String[] args) {
        // TODO code application logic here
        Random rand = new Random();
        
        char c1 = 'J';
        char c2 = 74;
        short qualityScore = 98;
        float miles = 175;
        float milesPerGallon = (float)18.5;
        float gasPrice = (float)2.85;
        boolean sunny = true;
        boolean summer = false;
        int hour = 23;
        double grade = 0.0 + (4.0 - 0.0)*rand.nextDouble();
        String greeting = "Hi";
        String myPawPrint = "joagnp";
        
        if(c1==c2){
            System.out.print(c1 + " and " + c2);
            System.out.print(" are the same.\n");
        }
        else{
            System.out.print(c1 + " and " + c2);
            System.out.print(" are NOT the same.\n");
        }
        
        if(qualityScore>=0 && qualityScore<=60){
            System.out.print("The quality is bad.\n");
        }
        else if(qualityScore>60 && qualityScore<=95){
            System.out.print("Good quality.");
        }
        else{
            System.out.print("Perfect.\n");
        }
        
        float gasUsed = miles/milesPerGallon;
        float gasFee = gasUsed*gasPrice;
        String gasUsageOutput = String.format("Total gas used = %.3f gallons", gasUsed);
        String gasFeeOutput = String.format("Total gas fee = $%.3f", gasFee);
        System.out.print(gasUsageOutput + "\n");
        System.out.print(gasFeeOutput + "\n");
        
        if(sunny==true && summer==true){
            System.out.print("Go swimming.\n");
        }
        else if(sunny==true && summer==false){
            System.out.print("Go hiking.\n");
        }
        else if(sunny==false && summer==false){
            System.out.print("Playing Games\n");
        }
        else{
            System.out.print("Stay home.\n");
        }
        
        switch(hour){
            case 23:
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
                System.out.print("The current time is " + hour + " in the NIGHT.\n");
                break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                System.out.print("The current time is " + hour + " in the MORNING.\n");
                break;
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
                System.out.print("The current time is " + hour + " in the AFTERNOON.\n");
                break;
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
                System.out.print("The current time is " + hour + " in the EVENING.\n");
                break;
            default:
                System.out.print("You have the wrong time.\n");
                break;
        }
        
        if(grade<0.70){
            System.out.print("The student's GPA grade is an F in the class.\n");
        }
        else if(grade<1.70){
            System.out.print("The student's GPA grade is a D- to D+ in the class.\n");
        }
        else if(grade<2.70){
            System.out.print("The student's GPA grade is a C- to C+ in the class.\n");
        }
        else if(grade<3.70){
            System.out.print("The student's GPA grade is a B- to B+ in the class.\n");
        }
        else{
            System.out.print("The student's GPA grade is an A- to A+ in the class.\n");
        }
        
        for(int count=1; count<=30; count++){
            if(count%7==0 || count%9==0){
                System.out.print("Count: " + count + "\n");
            }
        }
        
        int countDown = 3;
        while(countDown>0){
            System.out.print("Count Down: " + countDown + "\n");
            countDown--;
        }
        System.out.print("Go!\n");
        
        invokeMe(greeting, myPawPrint);
    }
    
}
