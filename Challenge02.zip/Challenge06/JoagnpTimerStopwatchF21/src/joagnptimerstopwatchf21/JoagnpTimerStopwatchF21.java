/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joagnptimerstopwatchf21;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author udohe
 */
public class JoagnpTimerStopwatchF21 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Label subHeading = new Label();
        subHeading.setText("Set up the start time:");
        subHeading.setMaxWidth(600);
        
        Label startTimePrompt = new Label();
        startTimePrompt.setText("Please set up the start time (Integer): ");
        startTimePrompt.setPrefWidth(800);
        
        TextField startTimeInput = new TextField();
        startTimeInput.setMaxWidth(600);
        
        Button ok = new Button();
        ok.setText("OK");
        
        Button cancel = new Button();
        cancel.setText("Cancel");
        
        
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(15));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.BASELINE_CENTER);
        grid.add(subHeading,0,0,1,1);
        grid.add(startTimePrompt,0,2,1,1);
        grid.add(startTimeInput,8,2,2,1);
        
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.BOTTOM_RIGHT);
        hbox.setPadding(new Insets(10));
        hbox.getChildren().addAll(ok, cancel);
        grid.add(hbox, 9, 3, 1, 1);
        
        Scene scene = new Scene(grid, 400, 200);
        
        primaryStage.setTitle("Timer Start Time Set Up");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
