/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joagnphelloworldf21;

/**
 *
 * @author Justin Agudah
 */
import java.time.format.DateTimeFormatter;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;

public class JoagnpHelloWorldF21 {

    static void invokeMe() {
        String myCourseNum = "CS3330";
        System.out.print("My Course Number is " + myCourseNum + ".\n");
        
        DateTimeFormatter dayFormat = DateTimeFormatter.ofPattern("EEEE");
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/dd/YYYY\n");
        DateFormat timeFormat = new SimpleDateFormat("h:mm aa");

        System.out.print("Today is " + dayFormat.format(java.time.LocalDate.now()) + "\n");
        System.out.print("Today's date is " + dateFormat.format(java.time.LocalDate.now()));
        System.out.print("and the Current Time is " + timeFormat.format(new Date()) + "\n");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("Hello World! ");

        String name = "Justin Agudah";
        System.out.print("My name is " + name + ".\n");

        invokeMe();
    }

}
